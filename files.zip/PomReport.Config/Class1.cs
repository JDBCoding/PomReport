﻿namespace PomReport.Config;

public class Class1
{

}
